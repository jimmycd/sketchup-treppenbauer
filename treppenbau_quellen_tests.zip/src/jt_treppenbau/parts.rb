# encoding: UTF-8
# Treppenbau – Zerlegung der Treppe in flache, fräsbare Einzelteile (mm).
#
# Jedes Teil wird so gedreht, dass seine Faserrichtung entlang +X liegt,
# und auf den Ursprung (min X / min Y = 0) geschoben.
#   Trittstufen/Podeste  – Faser entlang der Stufenvorderkante
#   Setzstufen           – Faser entlang der Länge
#   Wangen               – abgewickelt, Faser entlang der Wange; mit Nuten
#                          (Einstand) für Tritt- und Setzstufen
#   Pfosten / Handlauf   – nur gerade Stücke

module JTools
  module Treppenbau
    class Part
      attr_accessor :id, :label, :kind, :thickness, :poly, :pockets, :pocket_depth, :info

      def initialize(kind, label, thickness, poly, pockets = [], pocket_depth = 0.0, info = '')
        @kind = kind
        @label = label
        @thickness = thickness.round(1)
        @poly = poly
        @pockets = pockets
        @pocket_depth = pocket_depth
        @info = info
      end

      def area
        Geo.signed_area(@poly).abs
      end

      def size
        xs = @poly.map(&:first); ys = @poly.map(&:last)
        [xs.max - xs.min, ys.max - ys.min]
      end
    end

    module Parts
      module_function

      MM = 10.0
      KIND_NAMES = {
        tread: 'Trittstufe', landing: 'Podest', riser: 'Setzstufe', stringer: 'Wange',
        newel: 'Pfosten (Wange)', post: 'Geländerpfosten', rail: 'Handlauf'
      }.freeze

      # opts: :treads, :risers, :stringers, :posts, :rail (bool), :einstand (mm)
      def collect(plan, p, opts)
        parts = []
        warnings = []
        cons = p['construction']
        st_sides = Builder.stringer_sides(plan, p)
        einstand = st_sides.empty? ? 0.0 : opts[:einstand].to_f
        if cons == 'massiv'
          warnings << 'Massivtreppe: Stufen und Laufplatte sind Beton – es werden nur Geländerteile exportiert.'
        end

        if cons != 'massiv'
          parts.concat(treads(plan, p, st_sides, einstand)) if opts[:treads]
          parts.concat(risers(plan, p, st_sides, einstand)) if opts[:risers] && p['risers']
        end
        if cons == 'wange' && opts[:stringers]
          sp, sw = stringers(plan, p, einstand)
          parts.concat(sp); warnings.concat(sw)
        end
        if p['rail'] != 'keins'
          if opts[:posts]
            parts.concat(posts(plan, p))
          end
          if opts[:rail]
            rp, rw = rails(plan, p)
            parts.concat(rp); warnings.concat(rw)
          end
        end
        if cons == 'holm'
          warnings << 'Holm (Mittelholm) wird nicht exportiert (Stahl bzw. Kantholz).'
        end
        parts.each_with_index { |pt, i| pt.id = i + 1 }
        [parts, warnings]
      end

      # ---------------------------------------------------------------------
      # Trittstufen / Podeste

      def treads(plan, p, st_sides, einstand)
        lw = plan.lines_w
        ext = p['nosing'] + (p['risers'] ? p['riser_t'] : 0.0)
        res = []
        nr = 0
        (0...plan.treads).each do |k|
          poly = extended_region(plan, lw[k], [lw[k + 1] + ext, plan.wtot].min, st_sides, einstand)
          l = plan.line(lw[k])
          landing = plan.kinds[k] == :landing
          nr += 1 unless landing
          label = landing ? "P#{k + 1}" : "T#{k + 1}"
          axis = Geo.sub(l[:out], l[:in])
          axis = Geo.mul(axis, -1) if plan.outer_side < 0
          res << Part.new(landing ? :landing : :tread, label, p['tread_t'] * MM,
                          align(poly.map { |q| Geo.mul(q, MM) }, axis), [], 0.0,
                          landing ? 'Podest' : "Stufe #{k + 1}")
        end
        res
      end

      def risers(plan, p, st_sides, einstand)
        lw = plan.lines_w
        res = []
        (0...plan.treads).each do |k|
          l = plan.line(lw[k] + p['nosing'])
          len = Geo.dist(l[:in], l[:out]) * MM
          len += einstand if st_sides.include?(:outer)
          len += einstand if st_sides.include?(:inner) && plan.inner.length > 0
          hgt = (plan.h - p['tread_t']) * MM
          next if hgt < 5
          res << Part.new(:riser, "R#{k + 1}", p['riser_t'] * MM, rect(len, hgt), [], 0.0, "Setzstufe #{k + 1}")
        end
        res
      end

      # Stufenfläche, an den Wangenseiten um den Einstand verlängert (cm)
      def extended_region(plan, wa, wb, st_sides, einstand)
        la = plan.line(wa); lb = plan.line(wb)
        oc = [la[:out]] + plan.outer.between(la[:t], lb[:t]).map(&:first) + [lb[:out]]
        ic = [la[:in]] + plan.inner.between(la[:s], lb[:s]).map(&:first) + [lb[:in]]
        e = einstand / MM
        oc = offset_chain(oc, plan.outer_side, e) if e > 0 && st_sides.include?(:outer)
        ic = offset_chain(ic, -plan.outer_side, e) if e > 0 && st_sides.include?(:inner)
        Geo.clean_ring(oc + ic.reverse, 0.01)
      end

      def offset_chain(chain, side, d)
        c = []
        chain.each { |q| c << q if c.empty? || Geo.dist(c[-1], q) > 0.01 }
        return chain if c.size < 2
        mn = Geo.miter_normals(c, side)
        c.each_with_index.map { |q, i| Geo.add(q, Geo.mul(mn[i], d)) }
      end

      # ---------------------------------------------------------------------
      # Wangen (abgewickelt, nur gerade Abschnitte)

      def stringers(plan, p, einstand)
        res = []
        warnings = []
        r = Stringers.compute(plan, p)
        warnings.concat(r[:warnings])
        st = p['str_t']
        lw = plan.lines_w
        d = p['tread_t']; u = p['nosing']; ts = p['riser_t']
        ext = u + (p['risers'] ? ts : 0.0)
        skipped = 0
        pockets = {}
        %i[outer inner].each do |which|
          pk = []
          (0...plan.treads).each do |k|
            top = (k + 1) * plan.h
            pk << [Stringers.prm(plan, which, lw[k]), Stringers.prm(plan, which, [lw[k + 1] + ext, plan.wtot].min), top - d, top]
            if p['risers']
              pk << [Stringers.prm(plan, which, lw[k] + u), Stringers.prm(plan, which, lw[k] + u + ts), k * plan.h, top - d]
            end
          end
          pockets[which] = pk
        end
        cnt = Hash.new(0)
        r[:wange].each do |b|
          if b[:u1] - b[:u0] < 25.0
            skipped += 1
            next
          end
          cnt[b[:which]] += 1
          lbl = "W#{b[:which] == :outer ? 'A' : 'I'}#{cnt[b[:which]]}"
          res << board_part(b, b[:side] > 0, pockets[b[:which]], einstand, st * MM, lbl,
                            "Wange #{b[:which] == :outer ? 'außen' : 'innen'} #{cnt[b[:which]]}")
        end
        r[:newels].each do |nw|
          rail_here = p['rail'] == 'beide' || (p['rail'] == 'innen' && nw[:which] == :inner) || (p['rail'] == 'aussen' && nw[:which] == :outer)
          z1 = nw[:ztop] + (rail_here ? p['rail_h'] - p['str_over'] : 10.0)
          res << Part.new(:newel, "N#{res.count { |x| x.kind == :newel } + 1}", st * MM,
                          rect((z1 - nw[:zbot]) * MM, st * MM), [], 0.0, 'Eckpfosten Wange')
        end
        r[:sattel].each do |sb|
          if sb[:len] < 10.0
            skipped += 1
            next
          end
          lbl = "S#{sb[:which] == :outer ? 'A' : 'I'}#{sb[:nr]}"
          poly = sb[:poly].map { |x, z| [x * MM, z * MM] }
          mirror = sb[:side] > 0
          poly = poly.map { |x, z| [sb[:len] * MM - x, z] } if mirror
          axis = [1.0, 0.0]
          # Faser entlang der Unterkante (längste Kante)
          best = nil
          poly.each_with_index do |q, i|
            q2 = poly[(i + 1) % poly.size]
            l = Geo.dist(q, q2)
            best = [l, Geo.sub(q2, q)] if best.nil? || l > best[0]
          end
          axis = best[1] if best
          axis = Geo.mul(axis, -1) if axis[0] < 0
          rot, = rotation_for(axis)
          pp, = transform_all(poly, [], rot)
          res << Part.new(:stringer, lbl, sb[:t] * MM, pp, [], 0.0,
                          "Aufgesattelte Wange #{sb[:which] == :outer ? 'außen' : 'innen'} #{sb[:nr]}")
        end
        if skipped > 0
          warnings << "#{skipped} sehr kurze Wangenabschnitte (z. B. an Innenecken) fehlen im Export."
        end
        [res, warnings]
      end

      def board_part(b, mirror, pockets, einstand, thick, label, info)
        p0 = b[:u0]; p1 = b[:u1]
        mapx = ->(s) { (mirror ? (p1 - s) : (s - p0)) * MM }
        poly = Stringers.wange_outline(b).map { |x, z| [mapx.(p0 + x), z * MM] }
        poly = Geo.clean_ring(poly, 0.05)
        pk = []
        if einstand > 0
          pockets.each do |a, bb, z0, z1|
            a2 = [a, p0].max; b2 = [bb, p1].min
            next if b2 - a2 < 0.05
            xa = mapx.(a2); xb = mapx.(b2)
            pk << rect_pts([xa, xb].min, z0 * MM, [xa, xb].max, z1 * MM)
          end
        end
        # Faser entlang der Oberkante
        axis = [mapx.(p1) - mapx.(p0), (Stringers.top(b, p1) - Stringers.top(b, p0)) * MM]
        axis = Geo.mul(axis, -1) if axis[0] < 0
        rot, = rotation_for(axis)
        Part.new(:stringer, label, thick, *transform_all(poly, pk, rot), einstand, info)
      end

      # ---------------------------------------------------------------------
      # Geländer

      def rail_sides(plan, p)
        sides = case p['rail']
                when 'aussen' then [:outer]
                when 'innen' then [:inner]
                else [:outer, :inner]
                end
        sides.delete(:inner) if plan.spiral && plan.spiral[:ri] < 10
        sides
      end

      def posts(plan, p)
        res = []
        rh = p['rail_h']; r = p['rail_d'] / 2.0; ps = p['post_s']
        every = [p['post_every'].to_i, 1].max
        rail_sides(plan, p).each do |which|
          on_str = Builder.stringer_sides(plan, p).include?(which)
          over = on_str ? p['str_over'] : 0.0
          zs = (0...plan.n).map { |k| plan.nose_z(k) + rh }
          keys = plan.keys_for(which)
          plan.profile(which, zs).each do |pc|
            lens = []
            [pc[0], pc[-1]].each do |it|
              next unless it[3]
              zb = on_str ? (Stringers.top_at(plan, p, which, it[2]) || plan.nose_z(it[3]) + over) : plan.nose_z(it[3])
              lens << it[1] - r - zb
            end
            p0 = pc[0][2]; p1 = pc[-1][2]
            (0...plan.treads).each do |k|
              next unless (k + 1) % every == 0
              a = keys[k]; b = keys[k + 1]
              next if b - a < 1.0
              pm = (a + b) / 2.0
              next if pm <= p0 + 1.0 || pm >= p1 - 1.0
              zr = Builder.interp_piece(pc, pm)
              zb = on_str ? (Stringers.top_at(plan, p, which, pm) || zr - rh + over) : (k + 1) * plan.h
              lens << zr - r - zb
            end
            lens.each do |ln|
              next if ln < 2
              res << Part.new(:post, "G#{res.size + 1}", ps * MM, rect(ln * MM, ps * MM), [], 0.0, 'Geländerpfosten')
            end
          end
        end
        res
      end

      def rails(plan, p)
        res = []
        skipped = 0
        rd = p['rail_d']
        rail_sides(plan, p).each do |which|
          side = which == :outer ? plan.outer_side : -plan.outer_side
          off = Builder.stringer_sides(plan, p).include?(which) ? p['str_t'] / 2.0 : -p['rail_inset']
          zs = (0...plan.n).map { |k| plan.nose_z(k) + p['rail_h'] }
          plan.profile(which, zs).each do |pc|
            base = pc.map(&:first)
            mn = Geo.miter_normals(base, side)
            path = pc.each_with_index.map { |it, i| q = Geo.add(it[0], Geo.mul(mn[i], off)); [q[0], q[1], it[1]] }
            straight_runs(path).each do |a, b|
              ln = Math.sqrt((b[0] - a[0])**2 + (b[1] - a[1])**2 + (b[2] - a[2])**2)
              if ln < 25.0
                skipped += 1
                next
              end
              res << Part.new(:rail, "H#{res.size + 1}", rd * MM, rect(ln * MM, rd * MM), [], 0.0, 'Handlauf (gerades Stück)')
            end
          end
        end
        w = []
        w << "#{skipped} gebogene bzw. sehr kurze Handlaufstücke werden nicht exportiert." if skipped > 0
        [res, w]
      end

      # Gerade 3D-Abschnitte eines Pfads (Knick in Grundriss oder Steigung > 1°)
      def straight_runs(path)
        runs = []
        start = path[0]
        prev_dir = nil
        (1...path.size).each do |i|
          a = path[i - 1]; b = path[i]
          v = [b[0] - a[0], b[1] - a[1], b[2] - a[2]]
          l = Math.sqrt(v.map { |x| x * x }.sum)
          next if l < 1e-6
          v = v.map { |x| x / l }
          if prev_dir
            c = prev_dir.zip(v).map { |x, y| x * y }.sum
            if c < Math.cos(1.0 * Math::PI / 180.0)
              runs << [start, a]
              start = a
            end
          end
          prev_dir = v
        end
        runs << [start, path[-1]]
        runs
      end

      # ---------------------------------------------------------------------
      # Hilfsfunktionen

      def rect(l, w)
        [[0.0, 0.0], [l, 0.0], [l, w], [0.0, w]]
      end

      def rect_pts(x0, y0, x1, y1)
        [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]
      end

      def rotation_for(axis)
        [-Math.atan2(axis[1], axis[0])]
      end

      # Dreht so, dass axis entlang +X liegt, und schiebt auf den Ursprung.
      def align(poly, axis)
        rot, = rotation_for(axis)
        transform_all(poly, [], rot)[0]
      end

      def transform_all(poly, pockets, rot)
        r = ->(q) { Geo.rot(q, rot) }
        pp = poly.map(&r)
        pk = pockets.map { |pc| pc.map(&r) }
        minx = pp.map(&:first).min; miny = pp.map(&:last).min
        sh = ->(q) { [q[0] - minx, q[1] - miny] }
        pp = pp.map(&sh)
        pp.reverse! if Geo.signed_area(pp) < 0
        [pp, pk.map { |pc| pc.map(&sh) }]
      end
    end
  end
end
