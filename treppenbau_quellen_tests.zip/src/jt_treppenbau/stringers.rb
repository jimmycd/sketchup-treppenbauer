# encoding: UTF-8
# Treppenbau – Wangen aus geraden Brettern (ohne SketchUp-API, testbar).
#
# Eingestemmte Wange:
#   * je Brett (im Grundriss gerade) ist die Oberkante eine Gerade, die die
#     Verbindungslinie der Stufenvorderkanten um str_over (lotrecht) überragt –
#     auf geraden Läufen exakt konstant, in Wendelbereichen mindestens;
#   * alle Bretter haben dieselbe Breite (rechtwinklig zur Kante gemessen);
#   * die Unterkante liegt an jeder Stufe mindestens str_under unter der
#     Stufenunterkante (hinteres Ende des Einstands) – darf variieren.
#   Brettbreite: str_h > 0 fest (mit Prüfung), 0 = kleinster passender Wert.
# Aufgesattelte Wange:
#   * liegt unter den Stufen, um sat_inset von der Laufkante nach innen versetzt;
#   * Oberkante sägezahnförmig (Auflager je Stufe, senkrechte Ausklinkung hinter
#     der Setzstufe bzw. unter der Unterschneidung);
#   * Unterkante je Brett gerade, sat_rest rechtwinklig unter den inneren Ecken.
# Koordinaten im abgewickelten Brett: u = Parameter entlang der Begrenzungslinie
# (cm), z = Höhe (cm).

module JTools
  module Treppenbau
    module Stringers
      module_function

      KINK = 0.0175 # ~1°

      def compute(plan, p)
        cache = plan.instance_variable_get(:@stringers)
        return cache if cache
        res = { wange: [], sattel: [], newels: [], width: 0.0, need: 0.0, warnings: [] }
        if p['construction'] == 'wange' && !plan.spiral
          wange(plan, p, res)
          sattel(plan, p, res)
        end
        plan.instance_variable_set(:@stringers, res)
        res
      end

      def kind(plan, p, which)
        Params.side_kind(p, which, plan.outer_side, !plan.spiral.nil?)
      end

      def side_of(plan, which)
        which == :outer ? plan.outer_side : -plan.outer_side
      end

      # Parameter einer Stufenlinie auf der Begrenzung
      def prm(plan, which, w)
        l = plan.line([[w, 0.0].max, plan.wtot].min)
        which == :outer ? l[:t] : l[:s]
      end

      # Zerlegt ein Profilstück an Knickstellen (und an den Linien mit Index
      # in split) in gerade Bretter.
      def boards(pc, split = [])
        out = []
        cur = [pc[0]]
        dir = nil
        (1...pc.size).each do |i|
          d = Geo.norm(Geo.sub(pc[i][0], pc[i - 1][0]))
          if (dir && Geo.cross(dir, d).abs > KINK) || (i > 1 && pc[i - 1][3] && split.include?(pc[i - 1][3]))
            out << cur
            cur = [pc[i - 1]]
          end
          cur << pc[i]
          dir = d
        end
        out << cur
        out.select { |b| b.size >= 2 && Geo.dist(b[0][0], b[-1][0]) > 0.05 }
      end

      # Niedrigste Gerade z = c + s·u oberhalb aller Punkte (kleinster
      # größter Abstand). Kollineare Punkte -> exakt durch die Punkte.
      def top_line(pts)
        pts = pts.sort_by(&:first)
        return [pts[0][1], 0.0] if pts.size == 1 || (pts[-1][0] - pts[0][0]).abs < 1e-9
        hull = []
        pts.each do |q|
          while hull.size >= 2
            a = hull[-2]; b = hull[-1]
            cr = (b[0] - a[0]) * (q[1] - a[1]) - (b[1] - a[1]) * (q[0] - a[0])
            break if cr < -1e-9
            hull.pop
          end
          hull << q
        end
        best = nil
        hull.each_cons(2) do |a, b|
          next if (b[0] - a[0]).abs < 1e-9
          s = (b[1] - a[1]) / (b[0] - a[0])
          c = a[1] - s * a[0]
          ex = pts.map { |u, z| c + s * u - z }
          next if ex.min < -1e-6
          best = [ex.max, c, s] if best.nil? || ex.max < best[0]
        end
        unless best
          s = (pts[-1][1] - pts[0][1]) / (pts[-1][0] - pts[0][0])
          c = pts.map { |u, z| z - s * u }.max
          return [c, s]
        end
        [best[1], best[2]]
      end

      # Höchste Gerade unterhalb aller Punkte
      def bottom_line(pts)
        c, s = top_line(pts.map { |u, z| [u, -z] })
        [-c, -s]
      end

      # Gehrungs-Normale zwischen zwei Richtungen (side +1 rechts)
      def miter(d0, d1, side)
        n0 = side > 0 ? Geo.right(d0) : Geo.left(d0)
        n1 = side > 0 ? Geo.right(d1) : Geo.left(d1)
        m = Geo.norm(Geo.add(n0, n1))
        c = Geo.dot(m, n1)
        c = 0.3 if c < 0.3
        Geo.mul(m, 1.0 / c)
      end

      # Endnormale entlang einer (schrägen) Stufenlinie, so skaliert, dass der
      # rechtwinklige Versatz 1 beträgt.
      def along_line(lvec, seg_dir, side)
        n = side > 0 ? Geo.right(seg_dir) : Geo.left(seg_dir)
        l = Geo.norm(lvec)
        l = Geo.mul(l, -1) if Geo.dot(l, n) < 0
        c = Geo.dot(l, n)
        return n if c < 0.3
        Geo.mul(l, 1.0 / c)
      end

      # --- eingestemmte Wangen -------------------------------------------
      def wange(plan, p, res)
        over = p['str_over'].to_f
        under = p['str_under'].to_f
        d = p['tread_t'].to_f
        ext = p['nosing'].to_f + (p['risers'] ? p['riser_t'].to_f : 0.0)
        lw = plan.lines_w
        zs = (0...plan.n).map { |k| plan.nose_z(k) + over }
        boards = []
        need = 0.0
        %i[outer inner].each do |which|
          next unless kind(plan, p, which) == 'wange'
          side = side_of(plan, which)
          pieces = plan.profile(which, zs)
          piece_boards = []
          keys = plan.keys_for(which)
          landings = (0...plan.treads).select { |k| plan.kinds[k] == :landing }
          split = landings.flat_map { |k| [k, k + 1] }
          pieces.each_with_index do |pc, pi|
            bds = boards(pc, split)
            list = []
            bds.each_with_index do |bd, bi|
              u0 = bd[0][2]; u1 = bd[-1][2]
              # Podest: waagerechtes Brett (Podestoberfläche + Überstand)
              lk = landings.find { |k| u0 >= keys[k] - 1e-6 && u1 <= keys[k + 1] + 1e-6 }
              rq = if lk
                     [[u0, (lk + 1) * plan.h + over], [u1, (lk + 1) * plan.h + over]]
                   else
                     bd.map { |it| [it[2], it[1]] }
                   end
              c, s = top_line(rq)
              # Anforderungen unten: hinteres/vorderes Ende jeder Stufe minus Mindestabstand
              req = []
              (0...plan.treads).each do |k|
                ua = prm(plan, which, lw[k]); ub = prm(plan, which, [lw[k + 1] + ext, plan.wtot].min)
                a = [ua, u0].max; b = [ub, u1].min
                next if b - a < 0.01
                # an Innenecken trägt der Eckpfosten die über die Ecke laufende Stufe
                next if bi.zero? && pi > 0 && ua < u0 - 0.01
                next if bi == bds.size - 1 && pi < pieces.size - 1 && ub > u1 + 0.01
                zr = (k + 1) * plan.h - d - under
                req << [a, zr] << [b, zr]
              end
              k1 = Math.sqrt(1.0 + s * s)
              nd = req.map { |u, zr| (c + s * u - zr) / k1 }.max || 0.0
              need = [need, nd].max
              base = bd.map(&:first)
              dir = Geo.norm(Geo.sub(base[-1], base[0]))
              list << { which: which, side: side, base: base, us: bd.map { |it| it[2] }, u0: u0, u1: u1, req: rq, req_bot: req, landing: lk,
                        c: c, s: s, dir: dir, piece: pi, idx0: bd[0][3], idx1: bd[-1][3] }
            end
            # Splitter (< 3 cm, z. B. minimale Podestverlängerung) weglassen
            list = list.reject { |b| b[:u1] - b[:u0] < 3.0 } if list.size > 1
            # Endnormalen: Gehrung zwischen Brettern, sonst entlang der Stufenlinie
            list.each_with_index do |b, i|
              b[:n0] = if i > 0 then miter(list[i - 1][:dir], b[:dir], side)
                       elsif b[:idx0] then line_normal(plan, b[:idx0], b[:dir], side)
                       end
              b[:n1] = if i < list.size - 1 then miter(b[:dir], list[i + 1][:dir], side)
                       elsif b[:idx1] then line_normal(plan, b[:idx1], b[:dir], side)
                       end
            end
            piece_boards << list
            boards.concat(list)
          end
          # Pfosten an Innenecken (zwischen den Profilstücken)
          piece_boards.each_cons(2) do |pa, pb|
            next if pa.empty? || pb.empty?
            ba = pa[-1]; bb = pb[0]
            res[:newels] << { which: which, side: side, pt: ba[:base][-1], na: Geo.norm(ba[:n1] || seg_n(ba, side)),
                              nb: Geo.norm(bb[:n0] || seg_n(bb, side)),
                              ztop: [top(ba, ba[:u1]), top(bb, bb[:u0])].max, a: ba, b: bb }
          end
        end
        need = (need * 2.0).ceil / 2.0
        width = p['str_h'].to_f > 0 ? p['str_h'].to_f : need
        if p['str_h'].to_f > 0 && need > p['str_h'].to_f + 0.01
          res[:warnings] << format('Wangenhöhe %.1f cm zu gering – mindestens %.1f cm nötig (Mindestabstand unter den Stufen).', p['str_h'].to_f, need)
        end
        boards.each { |b| b[:w] = width }
        res[:newels].each { |nw| nw[:zbot] = [[bot(nw[:a], nw[:a][:u1]), bot(nw[:b], nw[:b][:u0])].min, 0.0].max }
        res[:wange] = boards
        res[:width] = width
        res[:need] = need
      end

      def seg_n(b, side)
        side > 0 ? Geo.right(b[:dir]) : Geo.left(b[:dir])
      end

      def line_normal(plan, idx, dir, side)
        l = plan.line(plan.lines_w[idx])
        along_line(Geo.sub(l[:out], l[:in]), dir, side)
      end

      def top(b, u)
        b[:c] + b[:s] * u
      end

      def bot(b, u)
        top(b, u) - b[:w] * Math.sqrt(1.0 + b[:s]**2)
      end

      # Oberkante der Wange an Parameter u einer Seite (für Geländerpfosten)
      def top_at(plan, p, which, u)
        r = compute(plan, p)
        b = r[:wange].find { |x| x[:which] == which && u >= x[:u0] - 1e-6 && u <= x[:u1] + 1e-6 }
        b ? top(b, u) : nil
      end

      # Abgewickeltes Brett (u relativ zu u0, z) als Polygon, Unterkante am Boden gekappt
      def wange_outline(b)
        u0 = b[:u0]; u1 = b[:u1]
        poly = [[0.0, top(b, u0)], [u1 - u0, top(b, u1)]]
        b0 = bot(b, u0); b1 = bot(b, u1)
        poly << [u1 - u0, [b1, 0.0].max]
        if (b0 < 0) != (b1 < 0)
          f = (0 - b1) / (b0 - b1)
          poly << [(u1 - u0) * (1 - f), 0.0]
        end
        poly << [0.0, [b0, 0.0].max]
        Geo.clean_ring(poly, 0.01)
      end

      # Unterkante je Basispunkt inkl. Bodenschnitt (für 3D-Band)
      def wange_band(b)
        base = []; tops = []; bots = []
        us = [b[:u0], b[:u1]]
        b0 = bot(b, b[:u0]); b1 = bot(b, b[:u1])
        if (b0 < 0) != (b1 < 0)
          f = (0 - b0) / (b1 - b0)
          us = [b[:u0], b[:u0] + f * (b[:u1] - b[:u0]), b[:u1]]
        end
        us.each do |u|
          base << Geo.add(b[:base][0], Geo.mul(b[:dir], (u - b[:u0]) * Geo.dist(b[:base][0], b[:base][-1]) / (b[:u1] - b[:u0])))
          tops << top(b, u)
          bots << [bot(b, u), 0.0].max
        end
        [base, tops, bots]
      end

      # --- aufgesattelte Wangen ------------------------------------------
      def sattel(plan, p, res)
        t = p['sat_t'].to_f; rest = p['sat_rest'].to_f; inset = p['sat_inset'].to_f
        d = p['tread_t'].to_f
        cut_ext = p['nosing'].to_f + (p['risers'] ? p['riser_t'].to_f : 0.0)
        lw = plan.lines_w
        %i[outer inner].each do |which|
          next unless kind(plan, p, which) == 'sattel'
          side = side_of(plan, which)
          src = []
          plan.send(which).pts.each { |q| src << q if src.empty? || Geo.dist(src[-1], q) > 0.01 }
          next if src.size < 2
          mn = Geo.miter_normals(src, side)
          off = inset + t / 2.0
          sp = Polyline.new(src.each_with_index.map { |q, i| Geo.add(q, Geo.mul(mn[i], -off)) })
          last = 0.0
          vat = lambda do |w|
            l = plan.line([[w, 0.0].max, plan.wtot].min)
            hit = which == :outer ? sp.ray_hit(l[:in], Geo.sub(l[:out], l[:in])) : sp.ray_hit(l[:out], Geo.sub(l[:in], l[:out]))
            last = [hit ? hit[1] : last, last].max
          end
          cuts = (0...plan.treads).map { |k| vat.(lw[k] + cut_ext) }
          v_end = vat.(plan.wtot)
          zt = (0...plan.treads).map { |k| (k + 1) * plan.h - d }
          corners = (0...plan.treads - 1).map { |k| [cuts[k + 1], zt[k]] } + [[v_end, zt[-1]]]
          # gerade Abschnitte der Mittellinie
          segs = []
          pts = sp.pts; cum = sp.cum
          start = 0
          (1...pts.size - 1).each do |i|
            d0 = Geo.norm(Geo.sub(pts[i], pts[i - 1])); d1 = Geo.norm(Geo.sub(pts[i + 1], pts[i]))
            if Geo.cross(d0, d1).abs > KINK
              segs << [cum[start], cum[i]]
              start = i
            end
          end
          segs << [cum[start], cum[-1]]
          # an Podesten teilen (Podest = eigenes waagerechtes Brett)
          lks = (0...plan.treads).select { |k| plan.kinds[k] == :landing }
          lks.flat_map { |k| [cuts[k], k + 1 < cuts.size ? cuts[k + 1] : v_end] }.each do |sv|
            segs = segs.flat_map { |a, b| sv > a + 0.5 && sv < b - 0.5 ? [[a, sv], [sv, b]] : [[a, b]] }
          end
          no = 0
          segs.each do |va, vb|
            v0 = [va, cuts[0]].max; v1 = [vb, v_end].min
            next if v1 - v0 < 1.0
            lk = lks.find { |k| v0 >= cuts[k] - 0.01 && v1 <= (k + 1 < cuts.size ? cuts[k + 1] : v_end) + 0.01 }
            cs = if lk
                   [[v0, zt[lk]], [v1, zt[lk]]]
                 else
                   corners.select { |v, _| v >= v0 - 0.01 && v <= v1 + 0.01 }
                 end
            if cs.size < 2
              before = corners.select { |v, _| v < v0 - 0.01 }.last
              after = corners.find { |v, _| v > v1 + 0.01 }
              cs = ([before] + cs + [after]).compact
            end
            next if cs.empty?
            c, s = cs.size == 1 ? [cs[0][1], 0.0] : bottom_line(cs)
            c -= rest * Math.sqrt(1 + s * s)
            ztop_at = lambda do |v, after|
              k = cuts.rindex { |cv| after ? cv <= v + 1e-9 : cv < v - 1e-9 }
              k ? zt[k] : 0.0
            end
            top = [[v0, ztop_at.(v0, true)]]
            cuts.each_with_index do |cv, k|
              next unless cv > v0 + 1e-6 && cv < v1 - 1e-6
              top << [cv, k > 0 ? zt[k - 1] : 0.0] << [cv, zt[k]]
            end
            top << [v1, ztop_at.(v1, false)]
            zb = ->(v) { c + s * v }
            bot = [[v1, [zb.(v1), 0.0].max]]
            if (zb.(v0) < 0) != (zb.(v1) < 0)
              f = -zb.(v0) / (zb.(v1) - zb.(v0))
              bot << [v0 + f * (v1 - v0), 0.0]
            end
            bot << [v0, [zb.(v0), 0.0].max]
            poly = Geo.clean_ring((top + bot).map { |v, z| [v - v0, z] }, 0.01)
            next if poly.size < 3 || Geo.signed_area(poly).abs < 1.0
            no += 1
            o = sp.at(v0); e = sp.at(v1)
            res[:sattel] << { which: which, side: side, origin: o, dir: Geo.norm(Geo.sub(e, o)), len: v1 - v0,
                              poly: poly, t: t, nr: no }
          end
        end
      end
    end
  end
end
