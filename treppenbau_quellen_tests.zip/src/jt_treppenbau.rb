# encoding: UTF-8
# Treppenbau – parametrische Treppen für SketchUp
# Gerade, viertel-/halbgewendelte, dreiläufige Treppen und Wendeltreppen,
# jederzeit über die gespeicherten Parameter änderbar.

require 'sketchup.rb'
require 'extensions.rb'

module JTools
  module Treppenbau
    EXT_VERSION = '1.4.0'.freeze
    ext = SketchupExtension.new('Treppenbau', File.join(File.dirname(__FILE__), 'jt_treppenbau', 'main'))
    ext.description = 'Parametrische Treppen: gerade Läufe, Podest- und Wendelstufen-Treppen (L/U/dreiläufig) ' \
                      'sowie Wendeltreppen mit Spindel oder Auge. Raumeinpassung ohne Luft (Wände, Wandwinkel, Treppenloch), je Seite Wange / aufgesattelt / frei. Parameterdialog mit Grundrissvorschau, CNC-Export (TCN für TpaCAD, wie dxf4tcn), ' \
                      'Prüfung nach DIN-18065-Richtwerten und nachträglicher Änderung.'
    ext.version = EXT_VERSION
    ext.creator = 'JTools'
    ext.copyright = '2026'
    Sketchup.register_extension(ext, true)
  end
end
