require_relative 'su_mock'
$LOAD_PATH.unshift File.expand_path('../src', __dir__)
%w[params geometry fit stringers builder parts].each { |f| require "jt_treppenbau/#{f}" }
include JTools::Treppenbau
fails = 0
Params::NOSPIRAL.each do |v|
  [{}, {'fit_mode'=>'raum','space_l'=>350,'space_w'=>260,'angle_left'=>84}].each do |extra|
    %w[rechts links].each do |dir|
      p = Params.normalize(Params.defaults.merge('variant'=>v,'direction'=>dir,'risers'=>true,'side_left'=>'wange','side_right'=>'sattel').merge(extra))
      begin; plan = Layout.compute(p); rescue PlanError => e; puts "#{v} #{extra.size} #{dir}: #{e.message}"; next; end
      r = Stringers.compute(plan, p)
      over = p['str_over']; under = p['str_under']; d = p['tread_t']
      ext = p['nosing'] + p['riser_t']
      maxover = 0; minover = 1e9; minunder = 1e9
      r[:wange].each do |b|
        b[:req].each do |u, z|
          o = Stringers.top(b, u) - (z - over)
          maxover = [maxover, o].max; minover = [minover, o].min
        end
        b[:req_bot].each do |u, zr|
          minunder = [minunder, zr + under - Stringers.bot(b, u)].min
        end
      end
      ws = r[:wange].map { |b| b[:w] }.uniq
      ok = minover >= over - 1e-6 && minunder >= under - 1e-6 && ws.size <= 1
      # Sattel: Restbreite an den Ecken
      srest = r[:sattel].map do |sb|
        pts = sb[:poly]; zs = pts.map(&:last)
        zs.max - zs.min
      end
      fails += 1 unless ok
      puts format('%-14s %-6s %-6s boards=%2d W=%.1f (need %.1f) over min/max %.2f/%.2f under min %.2f  sattel=%d %s', v, extra.empty? ? 'frei' : 'raum', dir,
                  r[:wange].size, r[:width], r[:need], minover, maxover, minunder, r[:sattel].size, ok ? 'OK' : 'FEHLER')
    end
  end
end
puts "Fehler: #{fails}"
