# encoding: UTF-8
# Treppenbau – Hauptmodul: Menüs, Symbolleiste, Kontextmenü, Attribute.

require 'sketchup.rb'
require 'json'

module JTools
  module Treppenbau
    PATH    = File.dirname(__FILE__) unless defined?(PATH)
    PATH_UI = File.join(PATH, 'ui') unless defined?(PATH_UI)
    DICT    = 'JT_Treppenbau'.freeze unless defined?(DICT)

    require File.join(PATH, 'params')
    require File.join(PATH, 'geometry')
    require File.join(PATH, 'fit')
    require File.join(PATH, 'stringers')
    require File.join(PATH, 'builder')
    require File.join(PATH, 'dialog')
    require File.join(PATH, 'parts')
    require File.join(PATH, 'nesting')
    require File.join(PATH, 'tcn')
    require File.join(PATH, 'cnc')
    require File.join(PATH, 'cnc_dialog')

    # --- Attribute ------------------------------------------------------------

    def self.stair?(ent)
      return false unless ent.is_a?(Sketchup::ComponentInstance) || ent.is_a?(Sketchup::Group)
      defn = ent.respond_to?(:definition) ? ent.definition : nil
      !defn.nil? && !defn.get_attribute(DICT, 'params').nil?
    end

    def self.read_params(defn)
      raw = defn.get_attribute(DICT, 'params')
      Params.normalize(raw ? JSON.parse(raw) : {})
    rescue JSON::ParserError
      Params.defaults
    end

    def self.write_params(defn, params)
      defn.set_attribute(DICT, 'params', JSON.generate(params))
      defn.set_attribute(DICT, 'version', EXT_VERSION)
    end

    def self.remember(params)
      @last = params.dup
      Sketchup.active_model.set_attribute(DICT, 'last', JSON.generate(params))
    end

    def self.last_params
      return Params.normalize(@last) if @last
      raw = Sketchup.active_model.get_attribute(DICT, 'last')
      raw ? Params.normalize(JSON.parse(raw)) : Params.defaults
    rescue StandardError
      Params.defaults
    end

    # Ausgewählte Treppe (auch wenn man sich in der Treppe befindet)
    def self.selected_stair
      model = Sketchup.active_model
      st = model.selection.find { |e| stair?(e) }
      return st if st
      path = model.active_path || []
      path.reverse.find { |e| stair?(e) }
    end

    # --- Befehle --------------------------------------------------------------

    def self.cmd_new
      StairDialog.open(nil)
    end

    def self.cmd_edit
      st = selected_stair
      if st
        StairDialog.open(st)
      else
        UI.messagebox('Bitte zuerst eine mit „Treppenbau“ erzeugte Treppe auswählen.')
      end
    end

    def self.cmd_cnc
      st = selected_stair
      if st
        CncDialog.open(st)
      else
        UI.messagebox('Bitte zuerst eine mit „Treppenbau“ erzeugte Treppe auswählen.')
      end
    end

    def self.icon(name, size)
      if Sketchup.platform == :platform_win && Sketchup.version.to_i >= 16
        File.join(PATH, 'icons', "#{name}.svg")
      else
        File.join(PATH, 'icons', "#{name}_#{size}.png")
      end
    end

    unless file_loaded?(__FILE__)
      c_new = UI::Command.new('Neue Treppe…') { cmd_new }
      c_new.tooltip = 'Neue Treppe'
      c_new.status_bar_text = 'Erzeugt eine parametrische Treppe (gerade, gewendelt, Wendeltreppe).'
      c_new.small_icon = icon('treppe_neu', 16)
      c_new.large_icon = icon('treppe_neu', 24)

      c_edit = UI::Command.new('Treppe bearbeiten…') { cmd_edit }
      c_edit.tooltip = 'Treppe bearbeiten'
      c_edit.status_bar_text = 'Öffnet die Parameter der ausgewählten Treppe.'
      c_edit.small_icon = icon('treppe_bearbeiten', 16)
      c_edit.large_icon = icon('treppe_bearbeiten', 24)
      c_edit.set_validation_proc { selected_stair ? MF_ENABLED : MF_GRAYED }

      c_cnc = UI::Command.new('CNC-Export (TCN für TpaCAD)…') { cmd_cnc }
      c_cnc.tooltip = 'Treppe → TCN (dxf4tcn)'
      c_cnc.status_bar_text = 'Stufen, Wangen und Geländerteile auf Rohplatten verschachteln und als TCN für TpaCAD ausgeben.'
      c_cnc.small_icon = icon('treppe_tcn', 16)
      c_cnc.large_icon = icon('treppe_tcn', 24)
      c_cnc.set_validation_proc { selected_stair ? MF_ENABLED : MF_GRAYED }

      menu = UI.menu('Extensions').add_submenu('Treppenbau')
      menu.add_item(c_new)
      menu.add_item(c_edit)
      menu.add_separator
      menu.add_item(c_cnc)

      tb = UI::Toolbar.new('Treppenbau')
      tb.add_item(c_new)
      tb.add_item(c_edit)
      tb.add_item(c_cnc)
      tb.restore

      UI.add_context_menu_handler do |cm|
        if Sketchup.active_model.selection.any? { |e| stair?(e) }
          cm.add_separator
          cm.add_item(c_edit)
          cm.add_item(c_cnc)
        end
      end

      file_loaded(__FILE__)
    end
  end
end
