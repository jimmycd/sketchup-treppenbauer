# encoding: UTF-8
# Treppenbau – Wangen aus geraden Brettern (ohne SketchUp-API, testbar).
#
# Eingestemmte Wange:
#   * je Brett (im Grundriss gerade) ist die Oberkante eine Gerade, die die
#     Verbindungslinie der Stufenvorderkanten um str_over (lotrecht) überragt –
#     auf geraden Läufen exakt konstant, in Wendelbereichen mindestens;
#   * alle Bretter haben dieselbe Breite (rechtwinklig zur Kante gemessen);
#   * die Unterkante liegt an jeder Stufe mindestens str_under unter der
#     Stufenunterkante (hinteres Ende des Einstands) – darf variieren.
#   Brettbreite: str_h > 0 fest (mit Prüfung), 0 = kleinster passender Wert.
#   Form „geschwungen“ (str_form = 'kurve'): Ober- und Unterkante sind – von
#   der Seite gesehen – stetige, knickfreie Kurven (monotone kubische
#   Hermite-Interpolation) je Laufabschnitt zwischen Podesten/Eckpfosten:
#     oben exakt str_over über jeder Stufenvorderkante (gerade Läufe: Gerade),
#     da monoton steigend liegt jede Trittstufe auf ganzer Tiefe mind. str_over
#     unter der Oberkante;
#     unten exakt str_under unter dem hinteren Ende jedes Einstands, monoton
#     steigend -> an keiner Stelle einer Stufe weniger als str_under.
#   Die Brettbreite ist dadurch variabel; Podeste bleiben eigene waagerechte
#   Bretter, die Bretter bleiben im Grundriss gerade (keine Biegung).
# Aufgesattelte Wange:
#   * liegt unter den Stufen, um sat_inset von der Laufkante nach innen versetzt;
#   * Oberkante sägezahnförmig (Auflager je Stufe, senkrechte Ausklinkung hinter
#     der Setzstufe bzw. unter der Unterschneidung);
#   * Unterkante je Brett gerade, sat_rest rechtwinklig unter den inneren Ecken.
# Koordinaten im abgewickelten Brett: u = Parameter entlang der Begrenzungslinie
# (cm), z = Höhe (cm).

module JTools
  module Treppenbau
    module Stringers
      module_function

      KINK = 0.0175 # ~1°

      def compute(plan, p)
        cache = plan.instance_variable_get(:@stringers)
        return cache if cache
        res = { wange: [], sattel: [], newels: [], width: 0.0, need: 0.0, warnings: [] }
        if p['construction'] == 'wange' && !plan.spiral
          wange(plan, p, res)
          sattel(plan, p, res)
        end
        plan.instance_variable_set(:@stringers, res)
        res
      end

      def kind(plan, p, which)
        Params.side_kind(p, which, plan.outer_side, !plan.spiral.nil?)
      end

      def side_of(plan, which)
        which == :outer ? plan.outer_side : -plan.outer_side
      end

      # Parameter einer Stufenlinie auf der Begrenzung
      def prm(plan, which, w)
        l = plan.line([[w, 0.0].max, plan.wtot].min)
        which == :outer ? l[:t] : l[:s]
      end

      # Zerlegt ein Profilstück an Knickstellen (und an den Linien mit Index
      # in split) in gerade Bretter.
      def boards(pc, split = [])
        out = []
        cur = [pc[0]]
        dir = nil
        (1...pc.size).each do |i|
          d = Geo.norm(Geo.sub(pc[i][0], pc[i - 1][0]))
          if (dir && Geo.cross(dir, d).abs > KINK) || (i > 1 && pc[i - 1][3] && split.include?(pc[i - 1][3]))
            out << cur
            cur = [pc[i - 1]]
          end
          cur << pc[i]
          dir = d
        end
        out << cur
        out.select { |b| b.size >= 2 && Geo.dist(b[0][0], b[-1][0]) > 0.05 }
      end

      # Niedrigste Gerade z = c + s·u oberhalb aller Punkte (kleinster
      # größter Abstand). Kollineare Punkte -> exakt durch die Punkte.
      def top_line(pts)
        pts = pts.sort_by(&:first)
        return [pts[0][1], 0.0] if pts.size == 1 || (pts[-1][0] - pts[0][0]).abs < 1e-9
        hull = []
        pts.each do |q|
          while hull.size >= 2
            a = hull[-2]; b = hull[-1]
            cr = (b[0] - a[0]) * (q[1] - a[1]) - (b[1] - a[1]) * (q[0] - a[0])
            break if cr < -1e-9
            hull.pop
          end
          hull << q
        end
        best = nil
        hull.each_cons(2) do |a, b|
          next if (b[0] - a[0]).abs < 1e-9
          s = (b[1] - a[1]) / (b[0] - a[0])
          c = a[1] - s * a[0]
          ex = pts.map { |u, z| c + s * u - z }
          next if ex.min < -1e-6
          best = [ex.max, c, s] if best.nil? || ex.max < best[0]
        end
        unless best
          s = (pts[-1][1] - pts[0][1]) / (pts[-1][0] - pts[0][0])
          c = pts.map { |u, z| z - s * u }.max
          return [c, s]
        end
        [best[1], best[2]]
      end

      # Höchste Gerade unterhalb aller Punkte
      def bottom_line(pts)
        c, s = top_line(pts.map { |u, z| [u, -z] })
        [-c, -s]
      end

      # Gehrungs-Normale zwischen zwei Richtungen (side +1 rechts)
      def miter(d0, d1, side)
        n0 = side > 0 ? Geo.right(d0) : Geo.left(d0)
        n1 = side > 0 ? Geo.right(d1) : Geo.left(d1)
        m = Geo.norm(Geo.add(n0, n1))
        c = Geo.dot(m, n1)
        c = 0.3 if c < 0.3
        Geo.mul(m, 1.0 / c)
      end

      # Endnormale entlang einer (schrägen) Stufenlinie, so skaliert, dass der
      # rechtwinklige Versatz 1 beträgt.
      def along_line(lvec, seg_dir, side)
        n = side > 0 ? Geo.right(seg_dir) : Geo.left(seg_dir)
        l = Geo.norm(lvec)
        l = Geo.mul(l, -1) if Geo.dot(l, n) < 0
        c = Geo.dot(l, n)
        return n if c < 0.3
        Geo.mul(l, 1.0 / c)
      end

      # --- eingestemmte Wangen -------------------------------------------
      def wange(plan, p, res)
        over = p['str_over'].to_f
        under = p['str_under'].to_f
        d = p['tread_t'].to_f
        ext = p['nosing'].to_f + (p['risers'] ? p['riser_t'].to_f : 0.0)
        lw = plan.lines_w
        curve = p['str_form'] == 'kurve'
        zs = (0...plan.n).map { |k| plan.nose_z(k) + over }
        boards = []
        need = 0.0
        %i[outer inner].each do |which|
          next unless kind(plan, p, which) == 'wange'
          side = side_of(plan, which)
          pieces = plan.profile(which, zs)
          piece_boards = []
          keys = plan.keys_for(which)
          landings = (0...plan.treads).select { |k| plan.kinds[k] == :landing }
          split = landings.flat_map { |k| [k, k + 1] }
          pieces.each_with_index do |pc, pi|
            bds = boards(pc, split)
            list = []
            bds.each_with_index do |bd, bi|
              u0 = bd[0][2]; u1 = bd[-1][2]
              # Podest: waagerechtes Brett (Podestoberfläche + Überstand)
              lk = landings.find { |k| u0 >= keys[k] - 1e-6 && u1 <= keys[k + 1] + 1e-6 }
              rq = if lk
                     [[u0, (lk + 1) * plan.h + over], [u1, (lk + 1) * plan.h + over]]
                   else
                     bd.map { |it| [it[2], it[1]] }
                   end
              c, s = top_line(rq)
              # Anforderungen unten: hinteres/vorderes Ende jeder Stufe minus Mindestabstand
              req = []
              steps = []
              (0...plan.treads).each do |k|
                ua = prm(plan, which, lw[k]); ub = prm(plan, which, [lw[k + 1] + ext, plan.wtot].min)
                a = [ua, u0].max; b = [ub, u1].min
                next if b - a < 0.01
                # an Innenecken trägt der Eckpfosten die über die Ecke laufende Stufe
                next if bi.zero? && pi > 0 && ua < u0 - 0.01
                next if bi == bds.size - 1 && pi < pieces.size - 1 && ub > u1 + 0.01
                zr = (k + 1) * plan.h - d - under
                req << [a, zr] << [b, zr]
                # hinteres Ende ohne Kappung am Austritt (für die Kurvenstützpunkte)
                ue = ub + [lw[k + 1] + ext - plan.wtot, 0.0].max
                steps << [k, a, b, zr, ue]
              end
              k1 = Math.sqrt(1.0 + s * s)
              nd = req.map { |u, zr| (c + s * u - zr) / k1 }.max || 0.0
              need = [need, nd].max
              base = bd.map(&:first)
              dir = Geo.norm(Geo.sub(base[-1], base[0]))
              list << { which: which, side: side, base: base, us: bd.map { |it| it[2] }, u0: u0, u1: u1, req: rq, req_bot: req, steps: steps,
                        keyed: bd.select { |it| it[3] }.map { |it| [it[2], it[1]] }, landing: lk,
                        c: c, s: s, dir: dir, piece: pi, idx0: bd[0][3], idx1: bd[-1][3] }
            end
            # Splitter (< 3 cm, z. B. minimale Podestverlängerung) weglassen
            list = list.reject { |b| b[:u1] - b[:u0] < 3.0 } if list.size > 1
            # Endnormalen: Gehrung zwischen Brettern, sonst entlang der Stufenlinie
            list.each_with_index do |b, i|
              b[:n0] = if i > 0 then miter(list[i - 1][:dir], b[:dir], side)
                       elsif b[:idx0] then line_normal(plan, b[:idx0], b[:dir], side)
                       end
              b[:n1] = if i < list.size - 1 then miter(b[:dir], list[i + 1][:dir], side)
                       elsif b[:idx1] then line_normal(plan, b[:idx1], b[:dir], side)
                       end
            end
            curve_piece(list, landings, plan) if curve
            piece_boards << list
            boards.concat(list)
          end
          # Pfosten an Innenecken (zwischen den Profilstücken)
          piece_boards.each_cons(2) do |pa, pb|
            next if pa.empty? || pb.empty?
            ba = pa[-1]; bb = pb[0]
            res[:newels] << { which: which, side: side, pt: ba[:base][-1], na: Geo.norm(ba[:n1] || seg_n(ba, side)),
                              nb: Geo.norm(bb[:n0] || seg_n(bb, side)),
                              ztop: [top(ba, ba[:u1]), top(bb, bb[:u0])].max, a: ba, b: bb }
          end
        end
        need = (need * 2.0).ceil / 2.0
        if curve
          ws = boards.flat_map { |b| perp_widths(b) }
          res[:wange] = boards
          res[:width] = ws.max || 0.0
          res[:wmin] = ws.min || 0.0
          res[:need] = res[:width]
          res[:newels].each { |nw| nw[:zbot] = [[bot(nw[:a], nw[:a][:u1]), bot(nw[:b], nw[:b][:u0])].min, 0.0].max }
          return
        end
        width = p['str_h'].to_f > 0 ? p['str_h'].to_f : need
        if p['str_h'].to_f > 0 && need > p['str_h'].to_f + 0.01
          res[:warnings] << format('Wangenhöhe %.1f cm zu gering – mindestens %.1f cm nötig (Mindestabstand unter den Stufen).', p['str_h'].to_f, need)
        end
        boards.each { |b| b[:w] = width }
        res[:newels].each { |nw| nw[:zbot] = [[bot(nw[:a], nw[:a][:u1]), bot(nw[:b], nw[:b][:u0])].min, 0.0].max }
        res[:wange] = boards
        res[:width] = width
        res[:need] = need
      end

      def seg_n(b, side)
        side > 0 ? Geo.right(b[:dir]) : Geo.left(b[:dir])
      end

      def line_normal(plan, idx, dir, side)
        l = plan.line(plan.lines_w[idx])
        along_line(Geo.sub(l[:out], l[:in]), dir, side)
      end

      def top(b, u)
        return interp(b[:tp], u) if b[:tp]
        b[:c] + b[:s] * u
      end

      def bot(b, u)
        return interp(b[:bp], u) if b[:bp]
        top(b, u) - b[:w] * Math.sqrt(1.0 + b[:s]**2)
      end

      # lineare Interpolation in einer Stützpunktliste [[u, z], ...]
      def interp(pts, u)
        return pts[0][1] if u <= pts[0][0]
        return pts[-1][1] if u >= pts[-1][0]
        i = pts.bsearch_index { |q| q[0] >= u } || pts.size - 1
        i = 1 if i < 1
        a = pts[i - 1]; b = pts[i]
        du = b[0] - a[0]
        du.abs < 1e-12 ? b[1] : a[1] + (b[1] - a[1]) * (u - a[0]) / du
      end

      # --- geschwungene Wange (variable Breite) ---------------------------

      # Monotone kubische Hermite-Interpolation (Fritsch–Carlson).
      # Liefert Lambda u -> z; außerhalb linear mit Endsteigung fortgesetzt.
      # Kollineare Punkte ergeben exakt eine Gerade.
      def pchip(pts)
        x = pts.map(&:first); y = pts.map(&:last)
        n = x.size
        return ->(_u) { y[0] } if n == 1
        h = (0...n - 1).map { |i| x[i + 1] - x[i] }
        d = (0...n - 1).map { |i| (y[i + 1] - y[i]) / h[i] }
        m = Array.new(n, 0.0)
        m[0] = d[0]; m[-1] = d[-1]
        (1...n - 1).each do |i|
          if d[i - 1] * d[i] <= 0
            m[i] = 0.0
          else
            w1 = 2 * h[i] + h[i - 1]; w2 = h[i] + 2 * h[i - 1]
            m[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i])
          end
        end
        # Endsteigungen begrenzen (Monotonie)
        if n > 2
          [[0, 0], [n - 1, n - 2]].each do |i, j|
            m[i] = 0.0 if m[i] * d[j] <= 0
            m[i] = 3 * d[j] if d[j].abs > 1e-12 && m[i] / d[j] > 3
          end
        end
        # außerhalb: Steigung höchstens die mittlere Steigung (keine steilen Ausläufer)
        avg = (y[-1] - y[0]) / (x[-1] - x[0])
        e0 = avg >= 0 ? [m[0], avg].min : [m[0], avg].max
        e1 = avg >= 0 ? [m[-1], avg].min : [m[-1], avg].max
        lambda do |u|
          return y[0] + e0 * (u - x[0]) if u <= x[0]
          return y[-1] + e1 * (u - x[-1]) if u >= x[-1]
          i = x.bsearch_index { |q| q > u } - 1
          i = [[i, 0].max, n - 2].min
          t = (u - x[i]) / h[i]
          t2 = t * t; t3 = t2 * t
          (2 * t3 - 3 * t2 + 1) * y[i] + (t3 - 2 * t2 + t) * h[i] * m[i] +
            (-2 * t3 + 3 * t2) * y[i + 1] + (t3 - t2) * h[i] * m[i + 1]
        end
      end

      # Stützpunkte je u zusammenfassen (oben: höchster, unten: niedrigster Wert)
      def merge_nodes(pts, top)
        out = []
        pts.sort_by(&:first).each do |u, z|
          if out.empty? || u - out[-1][0] > 1e-3
            out << [u, z]
          else
            out[-1][1] = top ? [out[-1][1], z].max : [out[-1][1], z].min
          end
        end
        out
      end

      SAMPLE = 2.0 # cm Stützpunktabstand der Kurven

      # Kurven für alle Bretter eines Profilstücks. Läufe zwischen Podesten
      # bekommen je eine durchgehende Ober- und Unterkante (stetig über die
      # Gehrungsfugen), Podestbretter bleiben waagerecht.
      def curve_piece(list, _landings, _plan)
        runs = []
        list.each do |b|
          if b[:landing] || runs.empty? || runs[-1][-1][:landing] || b[:u0] > runs[-1][-1][:u1] + 0.01
            runs << [b]
          else
            runs[-1] << b
          end
        end
        prev_fb = nil
        runs.each do |run|
          u0 = run[0][:u0]; u1 = run[-1][:u1]
          # Oberkante: durch Stufenvorderkanten + Überstand
          tn = run.flat_map { |b| b[:landing] ? b[:req] : b[:keyed] }
          tn += [[u0, run[0][:req].min_by { |u, _| (u - u0).abs }[1]], [u1, run[-1][:req].min_by { |u, _| (u - u1).abs }[1]]] unless run[0][:landing]
          tn = merge_nodes(tn, true)
          ft = run[0][:landing] ? ->(_u) { tn.map(&:last).max } : pchip(tn)
          # Unterkante: hinteres Ende jedes Einstands minus Mindestabstand
          st = {}
          run.each do |b|
            b[:steps].each do |k, a, e, zr, ue|
              cur = st[k]
              st[k] = cur ? [[cur[0], a].min, [cur[1], e].max, zr, ue] : [a, e, zr, ue]
            end
          end
          land_fb = nil
          if run[0][:landing]
            # Podest: Unterkante schließt an die des vorangehenden Laufs an und
            # läuft knickfrei (kubisch, monoton) in die Waagerechte über.
            z1 = st.values.map { |v| v[2] }.min
            if prev_fb
              z0 = prev_fb.(u0)
              s0 = (z0 - prev_fb.(u0 - 0.5)) / 0.5
              z1 ||= z0
              if z1 > z0 + 1e-6 && s0 > 1e-6
                len = [u1 - u0, 2.0 * (z1 - z0) / s0].min
                land_fb = lambda do |u|
                  next z1 if u >= u0 + len
                  t = [(u - u0) / len, 0.0].max
                  t2 = t * t; t3 = t2 * t
                  (2 * t3 - 3 * t2 + 1) * z0 + (t3 - 2 * t2 + t) * len * s0 + (-2 * t3 + 3 * t2) * z1
                end
              else
                zc = [z0, z1].min
                land_fb = ->(_u) { zc }
              end
            elsif z1
              land_fb = ->(_u) { z1 }
            end
          end
          bn = if run[0][:landing]
                 []
               else
                 # ungekürztes hinteres Ende (auch jenseits des Laufendes) -> gerade
                 # Läufe bleiben exakt gerade
                 merge_nodes(st.values.map { |_a, _e, zr, ue| [ue, zr] }, false)
               end
          # z nicht fallend erzwingen (Monotonie => Mindestabstand überall)
          (bn.size - 2).downto(0) { |i| bn[i][1] = [bn[i][1], bn[i + 1][1]].min }
          fb = if land_fb
                 land_fb
               elsif bn.empty?
                 ->(u) { ft.(u) - 30.0 }
               elsif run[0][:landing] || bn.size == 1
                 zc = bn.map(&:last).min
                 ->(_u) { zc }
               else
                 pchip(bn)
               end
          # Kontrolle: an keiner Stelle einer Stufe weniger als der Mindestabstand
          # (Sicherheitsnetz: sonst ganze Unterkante des Abschnitts absenken)
          drop = 0.0
          st.each_value do |a, e, zr, _ue|
            n = [((e - a) / 1.0).ceil, 1].max
            (0..n).each { |i| drop = [drop, fb.(a + (e - a) * i / n) - zr].max }
          end
          fb0 = fb
          fb = ->(u) { fb0.(u) - drop } if drop > 1e-6
          prev_fb = fb
          run.each do |b|
            # Stützpunkte: Brettenden und Kurvenknoten exakt, dazwischen alle SAMPLE cm
            inr = ->(u) { u > b[:u0] + 0.005 && u < b[:u1] - 0.005 }
            keys = (tn.map(&:first) + bn.map(&:first)).select(&inr).sort
            keys = keys.each_with_object([]) { |u, o| o << u if o.empty? || u - o[-1] > 0.005 }
            n = [((b[:u1] - b[:u0]) / SAMPLE).ceil, 1].max
            smp = (1...n).map { |i| b[:u0] + (b[:u1] - b[:u0]) * i / n }.select(&inr)
            smp.reject! { |u| keys.any? { |k| (k - u).abs <= 0.02 } }
            us = [b[:u0]] + (keys + smp).sort + [b[:u1]]
            b[:tp] = us.map { |u| [u, ft.(u)] }
            b[:bp] = us.map { |u| [u, [fb.(u), ft.(u) - 1.0].min] }
            b[:s] = (b[:tp][-1][1] - b[:tp][0][1]) / [b[:u1] - b[:u0], 1e-9].max
            b[:c] = b[:tp][0][1] - b[:s] * b[:u0]
          end
          # Kontrolle mit der tatsächlich gezeichneten (linear interpolierten) Unterkante
          drop2 = 0.0
          run.each do |b|
            b[:steps].each do |_k, a, e, zr|
              (0..20).each { |i| drop2 = [drop2, bot(b, a + (e - a) * i / 20.0) - zr].max }
            end
          end
          if drop2 > 1e-9
            run.each { |b| b[:bp].each { |q| q[1] -= drop2 + 1e-7 } }
            fb1 = prev_fb
            prev_fb = ->(u) { fb1.(u) - drop2 - 1e-7 }
          end
          run.each do |b|
            ws = perp_widths(b)
            b[:w] = ws.max
          end
        end
      end

      # Brettbreite rechtwinklig zur Oberkante an den Stützpunkten
      def perp_widths(b)
        return [b[:w]] unless b[:tp]
        tp = b[:tp]
        tp.each_index.map do |i|
          j0 = [i - 1, 0].max; j1 = [i + 1, tp.size - 1].min
          du = tp[j1][0] - tp[j0][0]
          s = du.abs < 1e-9 ? 0.0 : (tp[j1][1] - tp[j0][1]) / du
          (tp[i][1] - b[:bp][i][1]) / Math.sqrt(1 + s * s)
        end
      end

      # Oberkante der Wange an Parameter u einer Seite (für Geländerpfosten)
      def top_at(plan, p, which, u)
        r = compute(plan, p)
        b = r[:wange].find { |x| x[:which] == which && u >= x[:u0] - 1e-6 && u <= x[:u1] + 1e-6 }
        b ? top(b, u) : nil
      end

      # Abgewickeltes Brett (u relativ zu u0, z) als Polygon, Unterkante am Boden gekappt
      def wange_outline(b)
        return curve_outline(b) if b[:tp]
        u0 = b[:u0]; u1 = b[:u1]
        poly = [[0.0, top(b, u0)], [u1 - u0, top(b, u1)]]
        b0 = bot(b, u0); b1 = bot(b, u1)
        poly << [u1 - u0, [b1, 0.0].max]
        if (b0 < 0) != (b1 < 0)
          f = (0 - b1) / (b0 - b1)
          poly << [(u1 - u0) * (1 - f), 0.0]
        end
        poly << [0.0, [b0, 0.0].max]
        Geo.clean_ring(poly, 0.01)
      end

      # Unterkante je Basispunkt inkl. Bodenschnitt (für 3D-Band)
      # Unterkante als Polylinie, am Boden (z = 0) gekappt, mit Schnittpunkten
      def clipped_bottom(b)
        out = []
        b[:bp].each_with_index do |(u, z), i|
          if i > 0
            pu, pz = b[:bp][i - 1]
            if (pz < 0) != (z < 0)
              f = pz / (pz - z)
              out << [pu + f * (u - pu), 0.0]
            end
          end
          out << [u, [z, 0.0].max]
        end
        out
      end

      def curve_outline(b)
        u0 = b[:u0]
        poly = b[:tp].map { |u, z| [u - u0, z] } + clipped_bottom(b).reverse.map { |u, z| [u - u0, z] }
        Geo.clean_ring(poly, 0.01)
      end

      def wange_band(b)
        return curve_band(b) if b[:tp]
        base = []; tops = []; bots = []
        us = [b[:u0], b[:u1]]
        b0 = bot(b, b[:u0]); b1 = bot(b, b[:u1])
        if (b0 < 0) != (b1 < 0)
          f = (0 - b0) / (b1 - b0)
          us = [b[:u0], b[:u0] + f * (b[:u1] - b[:u0]), b[:u1]]
        end
        us.each do |u|
          base << Geo.add(b[:base][0], Geo.mul(b[:dir], (u - b[:u0]) * Geo.dist(b[:base][0], b[:base][-1]) / (b[:u1] - b[:u0])))
          tops << top(b, u)
          bots << [bot(b, u), 0.0].max
        end
        [base, tops, bots]
      end

      def curve_band(b)
        bb = clipped_bottom(b)
        us = (b[:tp].map(&:first) + bb.map(&:first)).sort
        us = us.each_with_object([]) { |u, o| o << u if o.empty? || u - o[-1] > 0.02 }
        us[-1] = b[:u1]
        len = Geo.dist(b[:base][0], b[:base][-1])
        base = us.map { |u| Geo.add(b[:base][0], Geo.mul(b[:dir], (u - b[:u0]) * len / (b[:u1] - b[:u0]))) }
        [base, us.map { |u| top(b, u) }, us.map { |u| [bot(b, u), 0.0].max }]
      end

      # --- aufgesattelte Wangen ------------------------------------------
      def sattel(plan, p, res)
        t = p['sat_t'].to_f; rest = p['sat_rest'].to_f; inset = p['sat_inset'].to_f
        d = p['tread_t'].to_f
        cut_ext = p['nosing'].to_f + (p['risers'] ? p['riser_t'].to_f : 0.0)
        lw = plan.lines_w
        %i[outer inner].each do |which|
          next unless kind(plan, p, which) == 'sattel'
          side = side_of(plan, which)
          src = []
          plan.send(which).pts.each { |q| src << q if src.empty? || Geo.dist(src[-1], q) > 0.01 }
          next if src.size < 2
          mn = Geo.miter_normals(src, side)
          off = inset + t / 2.0
          sp = Polyline.new(src.each_with_index.map { |q, i| Geo.add(q, Geo.mul(mn[i], -off)) })
          last = 0.0
          vat = lambda do |w|
            l = plan.line([[w, 0.0].max, plan.wtot].min)
            hit = which == :outer ? sp.ray_hit(l[:in], Geo.sub(l[:out], l[:in])) : sp.ray_hit(l[:out], Geo.sub(l[:in], l[:out]))
            last = [hit ? hit[1] : last, last].max
          end
          cuts = (0...plan.treads).map { |k| vat.(lw[k] + cut_ext) }
          v_end = vat.(plan.wtot)
          zt = (0...plan.treads).map { |k| (k + 1) * plan.h - d }
          corners = (0...plan.treads - 1).map { |k| [cuts[k + 1], zt[k]] } + [[v_end, zt[-1]]]
          # gerade Abschnitte der Mittellinie
          segs = []
          pts = sp.pts; cum = sp.cum
          start = 0
          (1...pts.size - 1).each do |i|
            d0 = Geo.norm(Geo.sub(pts[i], pts[i - 1])); d1 = Geo.norm(Geo.sub(pts[i + 1], pts[i]))
            if Geo.cross(d0, d1).abs > KINK
              segs << [cum[start], cum[i]]
              start = i
            end
          end
          segs << [cum[start], cum[-1]]
          # an Podesten teilen (Podest = eigenes waagerechtes Brett)
          lks = (0...plan.treads).select { |k| plan.kinds[k] == :landing }
          lks.flat_map { |k| [cuts[k], k + 1 < cuts.size ? cuts[k + 1] : v_end] }.each do |sv|
            segs = segs.flat_map { |a, b| sv > a + 0.5 && sv < b - 0.5 ? [[a, sv], [sv, b]] : [[a, b]] }
          end
          no = 0
          segs.each do |va, vb|
            v0 = [va, cuts[0]].max; v1 = [vb, v_end].min
            next if v1 - v0 < 1.0
            lk = lks.find { |k| v0 >= cuts[k] - 0.01 && v1 <= (k + 1 < cuts.size ? cuts[k + 1] : v_end) + 0.01 }
            cs = if lk
                   [[v0, zt[lk]], [v1, zt[lk]]]
                 else
                   corners.select { |v, _| v >= v0 - 0.01 && v <= v1 + 0.01 }
                 end
            if cs.size < 2
              before = corners.select { |v, _| v < v0 - 0.01 }.last
              after = corners.find { |v, _| v > v1 + 0.01 }
              cs = ([before] + cs + [after]).compact
            end
            next if cs.empty?
            c, s = cs.size == 1 ? [cs[0][1], 0.0] : bottom_line(cs)
            c -= rest * Math.sqrt(1 + s * s)
            ztop_at = lambda do |v, after|
              k = cuts.rindex { |cv| after ? cv <= v + 1e-9 : cv < v - 1e-9 }
              k ? zt[k] : 0.0
            end
            top = [[v0, ztop_at.(v0, true)]]
            cuts.each_with_index do |cv, k|
              next unless cv > v0 + 1e-6 && cv < v1 - 1e-6
              top << [cv, k > 0 ? zt[k - 1] : 0.0] << [cv, zt[k]]
            end
            top << [v1, ztop_at.(v1, false)]
            zb = ->(v) { c + s * v }
            bot = [[v1, [zb.(v1), 0.0].max]]
            if (zb.(v0) < 0) != (zb.(v1) < 0)
              f = -zb.(v0) / (zb.(v1) - zb.(v0))
              bot << [v0 + f * (v1 - v0), 0.0]
            end
            bot << [v0, [zb.(v0), 0.0].max]
            poly = Geo.clean_ring((top + bot).map { |v, z| [v - v0, z] }, 0.01)
            next if poly.size < 3 || Geo.signed_area(poly).abs < 1.0
            no += 1
            o = sp.at(v0); e = sp.at(v1)
            res[:sattel] << { which: which, side: side, origin: o, dir: Geo.norm(Geo.sub(e, o)), len: v1 - v0,
                              poly: poly, t: t, nr: no }
          end
        end
      end
    end
  end
end
